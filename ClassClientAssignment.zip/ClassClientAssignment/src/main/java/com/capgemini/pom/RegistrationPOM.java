package com.capgemini.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select; 

public class RegistrationPOM {
	
	@FindBy(how=How.ID, using="fName")
	public WebElement fname;
	
	@FindBy(how=How.ID, using="lName")
	public WebElement lname;
	
	@FindBy(how=How.ID, using="email")
	public WebElement email;
	
	@FindBy(how=How.ID, using="phonenumber")
	public WebElement phonenumber;
	
	@FindBy(how=How.ID, using="address")
	public WebElement address;
	
	public static Select state(WebDriver driver) {
		WebElement state = null;
		state=driver.findElement(By.id("state"));
		Select select = new Select(state);
		return select;
	}
	
	
	@FindBy(how=How.ID, using="city")
	public WebElement city;
	
	public static WebElement submit(WebDriver driver) {
		WebElement submitButton=driver.findElement(By.id("commit"));
		return submitButton;
	}
	
	@FindBy(how=How.ID, using="projectName")
	public WebElement projectName;
	
	@FindBy(how=How.ID, using="clientName")
	public WebElement clientName;
	
	@FindBy(how=How.ID, using="teamSize")
	public WebElement teamSize;
	
	public static WebElement register(WebDriver driver) {
		WebElement registerButton=driver.findElement(By.id("register"));
		return registerButton;
	}
	
}


























