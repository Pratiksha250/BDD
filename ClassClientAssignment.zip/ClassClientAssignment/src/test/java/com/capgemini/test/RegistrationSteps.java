package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.pom.RegistrationPOM;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationSteps {

	WebDriver driver;
	RegistrationPOM page;
	
	@Given("^User is on RegistrationTest Page$")
	public void user_is_on_RegistrationTest_Page()   {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\pdhandar\\Desktop\\3\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\ClassClientAssignment\\src\\main\\webapp\\RegistrationPage.html");
		
		page = PageFactory.initElements(driver, RegistrationPOM.class);
		

		
	
	     
	}

	@Then("^user has entered \"(.*?)\" as firstname$")
	public void user_has_entered_as_firstname(String arg1)   {
	   page.fname.sendKeys(arg1);  
	     
	}

	@And("^user has entered \"(.*?)\" as lastname$")
	public void user_has_entered_as_lastname(String arg1)   {
	     page.lname.sendKeys(arg1);
	     
	}

	@And("^user enters \"(.*?)\" as the email id$")
	public void user_enters_as_the_email_id(String arg1)   {
		 page.email.sendKeys(arg1);
	     
	}

	@And("^user enters \"(.*?)\" as contact number$")
	public void user_enters_as_contact_number(long arg1)   {
		 page.phonenumber.sendKeys(String.valueOf(arg1));
	     
	}

	@And("^user enters \"(.*?)\" as the address$")
	public void user_enters_as_the_address(String arg1)   {
		 page.address.sendKeys(arg1);
	     
	}

	@And("^user selects \"(.*?)\" as the state$")
	public void user_selects_as_the_state(String arg1)   {
	     RegistrationPOM.state(driver).selectByVisibleText(arg1);
	     
	}

	@And("^user enters \"(.*?)\" as the city$")
	public void user_enters_as_the_city(String arg1)   {
		page.city.sendKeys(arg1);   
	}

	@When("^user presses submit$")
	public void user_presses_submit()   {
	     RegistrationPOM.submit(driver).click();
			
			
	
	     
	}

	@Then("^the result should be \"(.*?)\" on the screen$")
	public void the_result_should_be_on_the_screen(String arg1)   {
		Alert alert = driver.switchTo().alert();
		String a=alert.getText();
		assertEquals(arg1, a);
		alert.accept();
	     
	}

	@When("^user enters \"(.*?)\" as the Project name$")
	public void user_enters_as_the_Project_name(String arg1)   {
		//driver = new ChromeDriver();
		driver.get("file:\\D:\\Module 3\\ClassClientAssignment\\src\\main\\webapp\\ClientPage.html");
		page =  PageFactory.initElements(driver, RegistrationPOM.class);
		
		page.projectName.sendKeys(arg1);
	     
	}

	@And("^user enters \"(.*?)\" as the Client name$")
	public void user_enters_as_the_Client_name(String arg1)   {
		page.clientName.sendKeys(arg1);
	     
	}

	@And("^user enters (\\d+) as the team size$")
	public void user_enters_as_the_team_size(int arg1)   {
		page.teamSize.sendKeys(String.valueOf(arg1));
	     
	}

	@When("^user presses register$")
	public void user_presses_register()   {
	     RegistrationPOM.register(driver).click();
	     
	}

	@Then("^\"(.*?)\" should be displayed on screen$")
	public void should_be_displayed_on_screen(String arg1)   {
		Alert alert = driver.switchTo().alert();
		String a=alert.getText();
		assertEquals(arg1, a);
		alert.accept();
		
	     
	}
	
}
